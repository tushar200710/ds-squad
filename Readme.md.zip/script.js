 // Function to preview the uploaded image
function previewImage() {
    const fileInput = document.getElementById('imageInput');
    const preview = document.getElementById('preview');
    const resultText = document.getElementById('classificationText');
    const disposalText = document.getElementById('disposalText');

    // Clear previous content
    preview.innerHTML = '';

    const file = fileInput.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            // Create an img element and show the uploaded image
            const img = document.createElement('img');
            img.src = e.target.result;
            preview.appendChild(img);
            preview.style.display = 'flex';

            // Call function to classify the image
            classifyWaste(img);
        };
        reader.readAsDataURL(file);
    }
}

// Function to mock classify the waste (replace with actual AI/ML logic)
function classifyWaste(image) {
    const resultText = document.getElementById('classificationText');
    const disposalText = document.getElementById('disposalText');

    // Mock classification (this should be replaced by actual model inference logic)
    let classification = '';
    let disposalLocation = '';

    if (image.src.includes('plastic')) {
        classification = 'Recyclable';
        disposalLocation = 'Nearest Recycling Center: 123 Eco Ave.';
    } else if (image.src.includes('glass')) {
        classification = 'Recyclable';
        disposalLocation = 'Nearest Glass Recycling Facility: 456 Green Rd.';
    } else {
        classification = 'Non-Recyclable';
        disposalLocation = 'Nearest Landfill: 789 Waste St.';
    }

    // Update UI with results
    resultText.textContent = classification;
    disposalText.textContent = disposalLocation;
}
